import java.util.Arrays;

public class Student implements Comparable <Student>, Enrollable<Subject> {
    public static final int MAX_NUM_SUBJECTS = 4;
    private String firstName;
    private String lastName;
    private long studentID;
    private Subject[] subjects = new Subject[MAX_NUM_SUBJECTS];
    private int numSubjects = 0;

    public Student(String firstName, String lastName, long studentID) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.studentID = studentID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public long getStudentID() {
        return studentID;
    }

    public void setStudentID(long studentID) {
        this.studentID = studentID;
    }

    @Override
    public int compareTo(Student o) {
        if (this.studentID > o.studentID)
            return 1;
        else if (this.studentID < o.studentID)
            return -1;
        else
            return 0;
    }

    public static void main(String[] args){
        Student[] s = new Student[3];
        s[0] = new Student("Emily", "Brown", 11111);
        s[1] = new Student("John", "Dunn", 10001);
        s[2] = new Student("Mary", "King", 22222);
        Arrays.sort(s);
        System.out.println(Arrays.toString(s));
        System.out.println(Printable.MAXIMUM_PIXEL_DENSITY);
    }

    @Override
    public String toString() {
        return "Student{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", studentID=" + studentID +
                '}';
    }

    @Override
    public boolean enrol(Subject subject) {
        if (numSubjects == MAX_NUM_SUBJECTS)
            return false;
        if (!subject.enrol(this))
            return false;
        subjects[numSubjects] = subject;
        numSubjects++;
        return true;
    }
}
