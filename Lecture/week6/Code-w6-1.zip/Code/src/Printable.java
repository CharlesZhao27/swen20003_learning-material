public interface Printable {
    int MAXIMUM_PIXEL_DENSITY = 1000;
    public default void print() {
        System.out.println(this.toString());
    }
}
