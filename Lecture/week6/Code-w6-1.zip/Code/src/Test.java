public class Test {
    public static void main(String args[]) {

        System.out.println("hello".compareTo("hello"));
        System.out.println("hello".compareTo("mello"));
        System.out.println("hello".compareTo("hemlo"));
        //System.out.println("hello".compareTo("flag"));
        System.out.println("hello".compareTo(""));
        //System.out.println("hello".compareTo("hellow"));

        // unicode A-Z = U+0041 - U+005A = 65-90 decimal
        // unicode a-z = U+0061 - U+007A = 97-122 decimal
        System.out.println("hello".compareTo("Hello"));

        // see the unicode for digit 0-9 to understand code below
        System.out.println("hello".compareTo("0ello"));

    }

}
