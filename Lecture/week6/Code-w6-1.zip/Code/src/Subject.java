import java.util.Arrays;

public class Subject implements Comparable<Subject>, Enrollable<Student>{
    public static final int MAX_NUM_STUDENTS = 300;
    private String name;
    private String code;
    private Student[] students = new Student[MAX_NUM_STUDENTS];
    private int numStudents = 0;

    public Subject(String name, String code) {
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "Subject{" +
                "name='" + name + '\'' +
                ", code='" + code + '\'' +
                '}';
    }

    @Override
    public int compareTo(Subject s) {
        return this.code.compareTo(s.code);
    }

    public static void main(String[] args) {
        Subject[] subjects = new Subject[4];
        subjects[0] = new Subject("OOSD", "SWEN20003");
        subjects[1] = new Subject("ALGO", "COMP20003");
        subjects[2] = new Subject("DB", "INFO20003");
        subjects[3] = new Subject("ELDS", "COMP20008");

        Arrays.sort(subjects);
        System.out.println(Arrays.toString(subjects));
    }

    @Override
    public boolean enrol(Student student) {
        if (numStudents == MAX_NUM_STUDENTS)
            return false;
        students[numStudents] = student;
        numStudents++;
        return true;
    }
}
