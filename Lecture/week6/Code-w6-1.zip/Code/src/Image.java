public abstract class Image implements Printable {
    //public void print() {
        //<block of code to execute>
    //}
}