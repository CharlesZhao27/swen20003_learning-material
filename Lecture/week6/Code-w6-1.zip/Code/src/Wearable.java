public interface Wearable {
    public void wear();
}
