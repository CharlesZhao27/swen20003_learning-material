public class Seatbelt implements Wearable {

    private Car car;

    private boolean isWorn = false;

    public Seatbelt(Car car) {
        this.car = car;
    }

    public void wear() {
        this.isWorn = true;
        this.car.setCanDrive(true);
    }
}
