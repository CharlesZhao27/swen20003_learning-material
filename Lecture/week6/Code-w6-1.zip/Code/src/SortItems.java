import java.util.Arrays;
public class SortItems {
    public static void main(String[] args) {
        String[] strings = new String[]{"dragon",
                "Jon Snow", "Game of Thrones"};
        System.out.println(Arrays.toString(strings));
        Arrays.sort(strings);
        System.out.println(Arrays.toString(strings));
    }
}
