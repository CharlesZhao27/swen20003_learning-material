public interface Enrollable<T>{
    int a = 0;
    boolean enrol(T t);
}
