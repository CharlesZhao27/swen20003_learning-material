import java.util.Random;
import java.util.Arrays;

public class RandomNumber implements Comparable<RandomNumber> {

    private static Random random = new Random();

    public final int number;

    public RandomNumber() {
        this.number = random.nextInt(100);
    }

    public int compareTo(RandomNumber randomNumber) {
        return this.number - randomNumber.number;
    }

    public String toString() {
        return Integer.toString(this.number);
    }

    public static void main(String args[]) {
        RandomNumber randomNumbers[] = new RandomNumber[10];

        for (int i = 0; i < randomNumbers.length; i++) {
            randomNumbers[i] = new RandomNumber();
        }

        System.out.println(Arrays.toString(randomNumbers));

        Arrays.sort(randomNumbers);

        System.out.println(Arrays.toString(randomNumbers));

        System.out.println("dadfd".compareTo("dadfi"));
    }

}
