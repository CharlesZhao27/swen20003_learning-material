public class Clothing implements Wearable {

    private String bodyPart;

    public Clothing(String bodyPart) {
        this.bodyPart = bodyPart;
    }

    public void wear() {
        System.out.format("%s is worn on your %s.\n",
                this.getClass().getName(), this.bodyPart);
    }
}
