public class Car {
    public void setCanDrive(boolean b) {
    }
}
