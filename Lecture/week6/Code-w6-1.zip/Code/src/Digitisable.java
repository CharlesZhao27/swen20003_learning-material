public interface Digitisable extends Printable {
    public void digitise();
}
