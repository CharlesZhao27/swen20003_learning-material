public abstract class SpreadSheet implements Printable {
    public abstract void print();
    /*public void print() {
		//<block of code to execute>
    }*/
}
