public class WingedRobot extends AerialRobot {
    private boolean isPushPlane;

    @Override
    public void move(Point p) {

    }
}
