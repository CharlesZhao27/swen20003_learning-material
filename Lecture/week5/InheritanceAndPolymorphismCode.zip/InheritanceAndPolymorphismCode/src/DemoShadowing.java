public class DemoShadowing {
    public static void main(String[] args) {
        RookS r1 = new RookS(4,3);
        System.out.println("r1: row print 1: " + r1.getCurrentRow());
        System.out.println("r1: row print 2: " + r1.currentRow);

        PieceS r2 = new RookS(4,3);
        System.out.println("r2: row print 1: " + r2.getCurrentRow());
        System.out.println("r2: row print 2: " + r2.currentRow);

    }
}
