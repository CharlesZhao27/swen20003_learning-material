public abstract class AerialRobot extends Robot {
    private double altitude;
    //@Override
    //public abstract void move(Point p);
}

