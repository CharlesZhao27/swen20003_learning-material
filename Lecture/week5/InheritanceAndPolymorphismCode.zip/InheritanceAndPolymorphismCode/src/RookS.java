public class RookS extends PieceS {
    public int currentRow;
    public int currentColumn;

    public RookS(int currentRow, int currentColumn) {
        super(currentRow, currentColumn);
        // Any other code
    }

    public int getCurrentRow() { return this.currentRow;}
    public void printInfo() {
        System.out.println("Location = (" + currentRow + "," +
                currentColumn + ")");
    }

    @Override
    public boolean isValidMove(int toRow, int toColumn) {
        boolean isValid = true;
        System.out.println("Rook class: isValidMove() method");
        if (!super.isValidMove(toRow, toColumn))
            return false;
        //Logic for checking valid move and set isValid
        return isValid;
    }
}
