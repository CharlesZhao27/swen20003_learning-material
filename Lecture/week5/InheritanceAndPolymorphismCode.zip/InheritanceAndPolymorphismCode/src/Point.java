public class Point {
    private double xCoordinate;
    private double yCoordinate;
}
