public class SubClass extends SuperClass {


}
