public abstract class Robot {
    private Point position;
    private double angle;
    private double batteryLevel;

    public abstract void move(Point p);
}
