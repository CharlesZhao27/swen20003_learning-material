import util.chess.*;

public class InheritanceTesterNew {
    public static void main(String[] args) {
/*        PieceP rook1 = new RookP(2, 4);
        PieceP rook2 = new RookP(2, 4);
        //System.out.println(rook1.equals(rook2));
        boolean a = new RookP(3,2) instanceof PieceP;
        System.out.println(a);
        System.out.println(new Piece(3,2) instanceof Rook);*/
    }
}
