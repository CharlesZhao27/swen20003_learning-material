import java.util.Random;

public class RobotApp {

    public static void main(String[] args) {
        final int MAX_ROBOTS = 10;
        Robot[] swarm = new Robot[MAX_ROBOTS];

        for (int i = 0; i < MAX_ROBOTS; i++) {
            swarm[i] = createRobot();
        }
        move(swarm);
    }

    private static Robot createRobot() {
        final int NUM_ROBOT_TYPES = 1;
        Random rand = new Random();

        switch(rand.nextInt(NUM_ROBOT_TYPES)) {
            case 0:
                return new WingedRobot();
            case 1:
                return new RotaryRobot();
            default:
                return null;
        }

    }

    private static void move(Robot[] swarm) {
        for (Robot r : swarm) {
            r.move(new Point());
        }
    }

}
