public class RotaryRobot extends AerialRobot {
    private int numRotors;

    @Override
    public void move(Point p) {

    }
}
