public class SuperClass {
    public void myMethod(int a) {

    }
}
