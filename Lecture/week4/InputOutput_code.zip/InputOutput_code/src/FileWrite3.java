import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileWrite3 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        try (PrintWriter pw =
                     new PrintWriter(new FileWriter("test5.html"))) {

            pw.println("<h1>The Chronicles of SWEN20003</h1>");

            while (scanner.hasNext()) {
                String text = scanner.nextLine();

                pw.println("<p>" + text + "</p>");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
