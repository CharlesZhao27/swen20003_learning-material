import java.util.Scanner;

public class TestScanner1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your input: ");
        double d = scanner.nextDouble();
        String s1 = scanner.next();
        String s2 = scanner.nextLine();

        System.out.format("%3.2f,%s,%s", d, s2, s1);
    }
}
