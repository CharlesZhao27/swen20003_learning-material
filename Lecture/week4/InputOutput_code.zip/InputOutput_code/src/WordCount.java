import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class WordCount {
    public static void main(String[] args) {

        try (BufferedReader br =
                     new BufferedReader(new FileReader("test.txt"))) {
            String text;
            int count = 0;

            while ((text = br.readLine()) != null) {
                String words[] = text.split(" ");

                count += words.length;
            }

            System.out.println("# Words = " + count);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
