public class Actor {
    public static final int MAX_RATING = 10;

    public String name;
    public double rating;
    public String review;

    public Actor(String name, double rating, String review) {
        this.name = name;
        this.rating = rating;
        this.review = review;
    }

    public String toString() {
        return String.format("You gave %s a rating of %f/%d\n",
                name, rating, MAX_RATING)
                + String.format("Your review: '%s'", review);
    }
}
