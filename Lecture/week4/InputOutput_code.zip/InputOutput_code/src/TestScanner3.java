import java.util.Scanner;

public class TestScanner3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your input: ");
        double d = scanner.nextDouble();
        scanner.nextLine();
        String s1 = scanner.nextLine();
        String s2 = scanner.nextLine();

        System.out.format("%3.2f, %s, %s", d, s1, s2);
    }
}
