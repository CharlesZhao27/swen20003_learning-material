import java.io.FileReader;
import java.util.Scanner;
import java.io.IOException;

public class ReadFile2 {
    public static void main(String[] args) {

        try (Scanner file = new Scanner(new FileReader("test.txt"))) {

            while (file.hasNextLine()) {
		        System.out.println(file.nextLine());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
