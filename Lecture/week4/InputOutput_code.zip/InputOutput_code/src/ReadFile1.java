import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class ReadFile1 {
    public static void main(String[] args) {

        try (BufferedReader br = new BufferedReader(new FileReader("test.txt"))) {

            String text = null;

            while ((text = br.readLine()) != null) {
				System.out.println(text);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
