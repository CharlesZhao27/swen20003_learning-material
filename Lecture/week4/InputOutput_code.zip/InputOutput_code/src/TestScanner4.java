import java.util.Scanner;

public class TestScanner4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String  name = scanner.nextLine();

        double rating = scanner.nextDouble();
        scanner.nextLine();

        String comment = scanner.nextLine();

        Actor actor = new Actor(name, rating, comment);
        System.out.println(actor);
    }
}
