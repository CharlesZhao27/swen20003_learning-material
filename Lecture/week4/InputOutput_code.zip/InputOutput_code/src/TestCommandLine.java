public class TestCommandLine {
        public static void main(String[] args) {
            int age = Integer.parseInt(args[0]);
            double height = Double.parseDouble(args[1]);
            String name = args[2];

            Person person = new Person(age, height, name);
            System.out.println(person);
        }
}
