import java.util.Scanner;
import java.io.File;

public class MarkHist {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter filename: ");
        String filename = scanner.nextLine();

        System.out.print("Enter min value: ");
        int min = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter max value: ");
        int max = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter bin width: ");
        int width = scanner.nextInt();
        scanner.nextLine();

        int data[] = new int[max - min + 1];

        int total = 0;

        try (Scanner file = new Scanner(new File(filename))) {
            // Skip the first line
            file.nextLine();

            while (file.hasNext()) {
                String line[] = file.nextLine().split(",");

                int d = Integer.parseInt(line[1]);

                data[d - min] += 1;
                total += 1;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        // Print out graph
        for (int i = 0; i < data.length; i += width) {
            int sum = 0;

            // Bundle into *width* sized blocks
            for (int j = 0; j < width && i + j < data.length; j++) {
                sum += data[i + j];
            }

            int percentage = (int) (100 * (1.0 * sum) / total);
            String bar = "";

            if (percentage > 0) {
                bar = String.format("%" + percentage + "s", " ")
                        .replace(" ", "=");
            }

            int lower = i + min;
            int upper = lower + width - 1;

            // Print the block
            System.out.format("%03d-%03d: %s\n", lower, upper, bar);
        }

    }
}