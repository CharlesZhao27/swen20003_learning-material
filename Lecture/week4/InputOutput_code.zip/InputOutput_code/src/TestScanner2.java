import java.util.Scanner;

public class TestScanner2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your input: ");
        double d = scanner.nextDouble();
        float f = scanner.nextFloat();
        int i = scanner.nextInt();

        System.out.format("%3.2f , %3.2f , %3d", d, f, i);
    }
}
