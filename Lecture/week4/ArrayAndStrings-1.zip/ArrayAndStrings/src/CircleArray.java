public class CircleArray {
    public static void main (String[] args){
        //declare an array for Circles
        Circle[] circleArray = new Circle[3];

        // create circle objects and store in array
        for ( int i = 0;  i < circleArray.length; i++) {
            circleArray[i] = new Circle(i,i, i + 2);
        }
        for ( int i = 0;  i < circleArray.length; i++) {
            System.out.println("Circle " + i + " Radius=" +
                    circleArray[i].getRadius());
        }
    }
}
