import java.util.Arrays;

public class ArrayExample {
    public static void main(String[] args) {
        int[] intArray_1 = {0, 1, 2, 3, 4};
        System.out.println("Length = " + intArray_1.length + " Element [5] " + intArray_1[4]);
        int[] intArray_2 = new int[10];
        System.out.println("Length = " + intArray_2.length + " Element [5] " + intArray_2[4]);
        computeDoublePowers(10);

        int[] n1 = {1, 2, 3};
        int[] n2 = {1, 2, 3};
        System.out.println(Arrays.equals(n1, n2));

        int[] intArray = new int[5];
        intArray = new int[intArray.length + 1];
        System.out.println("Array Lenght = " + intArray.length);
    }

    public static double[] computeDoublePowers(int n) {
        double[] nums = new double[n];

        for (int i = 0; i < n; i++) {
            nums[i] = Math.pow(2, i);
        }

        // For sanity checking
        for (int i = 0; i < n; i++) {
            System.out.println(nums[i]);
        }

        return nums;
    }
}
